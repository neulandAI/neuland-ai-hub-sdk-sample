# ProjectLibrary


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **datetime** | UTC timestamp when the record was created. | [optional] 
**updated_at** | **datetime** | UTC timestamp when the record was last updated. | [optional] 
**creator_user_id** | **int** | ID of the user who created the record. | 
**updater_user_id** | **int** |  | [optional] 
**project_id** | **int** | ID of the project. | 
**library_id** | **int** | ID of the library linked to the project. | 

## Example

```python
from neuland_hub_sdk.models.project_library import ProjectLibrary

# TODO update the JSON string below
json = "{}"
# create an instance of ProjectLibrary from a JSON string
project_library_instance = ProjectLibrary.from_json(json)
# print the JSON string representation of the object
print(ProjectLibrary.to_json())

# convert the object into a dict
project_library_dict = project_library_instance.to_dict()
# create an instance of ProjectLibrary from a dict
project_library_from_dict = ProjectLibrary.from_dict(project_library_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


