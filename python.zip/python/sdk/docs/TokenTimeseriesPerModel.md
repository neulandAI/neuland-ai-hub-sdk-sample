# TokenTimeseriesPerModel

\"Represents token usage timeseries for a specific LLM model.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**llm_model** | **str** | Catalog name of the model. | 
**timeseries** | **Dict[str, List[TokenTimeseriesPoint]]** | Per-metric timeseries keyed by metric name (PromptTokens, CompletionTokens, TotalTokens). | 

## Example

```python
from neuland_hub_sdk.models.token_timeseries_per_model import TokenTimeseriesPerModel

# TODO update the JSON string below
json = "{}"
# create an instance of TokenTimeseriesPerModel from a JSON string
token_timeseries_per_model_instance = TokenTimeseriesPerModel.from_json(json)
# print the JSON string representation of the object
print(TokenTimeseriesPerModel.to_json())

# convert the object into a dict
token_timeseries_per_model_dict = token_timeseries_per_model_instance.to_dict()
# create an instance of TokenTimeseriesPerModel from a dict
token_timeseries_per_model_from_dict = TokenTimeseriesPerModel.from_dict(token_timeseries_per_model_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


