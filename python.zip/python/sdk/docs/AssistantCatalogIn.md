# AssistantCatalogIn


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | 
**description** | **str** |  | [optional] 
**avatar** | **str** |  | [optional] 
**instructions** | **str** |  | [optional] 
**llm_catalog_id** | **UUID** |  | [optional] 
**temperature** | **float** |  | [optional] 
**similarity_top_k** | **int** |  | [optional] 
**version** | **str** |  | [optional] 
**predefined_prompts** | **List[str]** |  | [optional] 

## Example

```python
from neuland_hub_sdk.models.assistant_catalog_in import AssistantCatalogIn

# TODO update the JSON string below
json = "{}"
# create an instance of AssistantCatalogIn from a JSON string
assistant_catalog_in_instance = AssistantCatalogIn.from_json(json)
# print the JSON string representation of the object
print(AssistantCatalogIn.to_json())

# convert the object into a dict
assistant_catalog_in_dict = assistant_catalog_in_instance.to_dict()
# create an instance of AssistantCatalogIn from a dict
assistant_catalog_in_from_dict = AssistantCatalogIn.from_dict(assistant_catalog_in_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


