# CostPromptTokens1

Cost per prompt token in the billing currency.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from neuland_hub_sdk.models.cost_prompt_tokens1 import CostPromptTokens1

# TODO update the JSON string below
json = "{}"
# create an instance of CostPromptTokens1 from a JSON string
cost_prompt_tokens1_instance = CostPromptTokens1.from_json(json)
# print the JSON string representation of the object
print(CostPromptTokens1.to_json())

# convert the object into a dict
cost_prompt_tokens1_dict = cost_prompt_tokens1_instance.to_dict()
# create an instance of CostPromptTokens1 from a dict
cost_prompt_tokens1_from_dict = CostPromptTokens1.from_dict(cost_prompt_tokens1_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


