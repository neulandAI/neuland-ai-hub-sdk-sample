# RoleUpdateIn


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**permissions** | **List[str]** |  | [optional] 

## Example

```python
from neuland_hub_sdk.models.role_update_in import RoleUpdateIn

# TODO update the JSON string below
json = "{}"
# create an instance of RoleUpdateIn from a JSON string
role_update_in_instance = RoleUpdateIn.from_json(json)
# print the JSON string representation of the object
print(RoleUpdateIn.to_json())

# convert the object into a dict
role_update_in_dict = role_update_in_instance.to_dict()
# create an instance of RoleUpdateIn from a dict
role_update_in_from_dict = RoleUpdateIn.from_dict(role_update_in_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


