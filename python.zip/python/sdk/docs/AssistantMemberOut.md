# AssistantMemberOut

An assistant membership, identifying the assistant and member by public id.  `assistant_id`/`user_id` (int) are kept alongside the public ids (dual-key — both are returned permanently); external clients should reference `assistant_public_id`/`user_public_id`.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**assistant_id** | **int** | Internal id of the assistant (deprecated; use assistant_public_id). | 
**assistant_public_id** | **UUID** | Public id of the assistant. | 
**user_id** | **int** | Internal id of the member user (deprecated; use user_public_id). | 
**user_public_id** | **UUID** | Public id of the member user. | 
**granted_via** | [**AssistantMemberGrantedViaEnum**](AssistantMemberGrantedViaEnum.md) | How the membership was granted. | 

## Example

```python
from neuland_hub_sdk.models.assistant_member_out import AssistantMemberOut

# TODO update the JSON string below
json = "{}"
# create an instance of AssistantMemberOut from a JSON string
assistant_member_out_instance = AssistantMemberOut.from_json(json)
# print the JSON string representation of the object
print(AssistantMemberOut.to_json())

# convert the object into a dict
assistant_member_out_dict = assistant_member_out_instance.to_dict()
# create an instance of AssistantMemberOut from a dict
assistant_member_out_from_dict = AssistantMemberOut.from_dict(assistant_member_out_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


