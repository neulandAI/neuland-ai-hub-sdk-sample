# UserGroupMember

Membership of a user in a group (within a tenant).

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**group_id** | **int** |  ID of the user group. | 
**user_id** | **int** | ID of the user. | 
**tenant_id** | **int** | ID of the tenant. | 
**creator_user_id** | **int** |  | 
**created_at** | **datetime** | Timestamp when the user group was created. | [optional] 

## Example

```python
from neuland_hub_sdk.models.user_group_member import UserGroupMember

# TODO update the JSON string below
json = "{}"
# create an instance of UserGroupMember from a JSON string
user_group_member_instance = UserGroupMember.from_json(json)
# print the JSON string representation of the object
print(UserGroupMember.to_json())

# convert the object into a dict
user_group_member_dict = user_group_member_instance.to_dict()
# create an instance of UserGroupMember from a dict
user_group_member_from_dict = UserGroupMember.from_dict(user_group_member_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


