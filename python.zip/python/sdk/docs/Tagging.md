# Tagging


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **datetime** | UTC timestamp when the record was created. | [optional] 
**updated_at** | **datetime** | UTC timestamp when the record was last updated. | [optional] 
**tag_id** | **int** | ID of the tag being applied. | 
**taggable_type** | **str** | Resource type this tag is attached to. | 
**taggable_id** | **int** | ID of the resource. | 
**tenant_id** | **int** | ID of the tenant that owns the tagging. | 
**creator_user_id** | **int** |  | [optional] 

## Example

```python
from neuland_hub_sdk.models.tagging import Tagging

# TODO update the JSON string below
json = "{}"
# create an instance of Tagging from a JSON string
tagging_instance = Tagging.from_json(json)
# print the JSON string representation of the object
print(Tagging.to_json())

# convert the object into a dict
tagging_dict = tagging_instance.to_dict()
# create an instance of Tagging from a dict
tagging_from_dict = Tagging.from_dict(tagging_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


