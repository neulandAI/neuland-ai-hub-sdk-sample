# UserPreferenceOut


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Unique identifier of the preference record. | 
**user_id** | **int** | Identifier of the user these preferences belong to. | 
**theme_mode** | [**ThemeModeEnum**](ThemeModeEnum.md) |  | [optional] 
**lang** | **str** |  | [optional] 
**timezone** | **str** |  | [optional] 

## Example

```python
from neuland_hub_sdk.models.user_preference_out import UserPreferenceOut

# TODO update the JSON string below
json = "{}"
# create an instance of UserPreferenceOut from a JSON string
user_preference_out_instance = UserPreferenceOut.from_json(json)
# print the JSON string representation of the object
print(UserPreferenceOut.to_json())

# convert the object into a dict
user_preference_out_dict = user_preference_out_instance.to_dict()
# create an instance of UserPreferenceOut from a dict
user_preference_out_from_dict = UserPreferenceOut.from_dict(user_preference_out_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


