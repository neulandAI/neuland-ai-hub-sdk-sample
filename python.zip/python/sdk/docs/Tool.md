# neuland_hub_sdk.Tool

All URIs are relative to *https://api.your-domain.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**tools_create_tool**](Tool.md#tools_create_tool) | **POST** /tools/ | Create a tool
[**tools_delete_tool**](Tool.md#tools_delete_tool) | **DELETE** /tools/{tool_id} | Delete a tool
[**tools_update_tool**](Tool.md#tools_update_tool) | **PATCH** /tools/{tool_id} | Update a tool


# **tools_create_tool**
> ToolOut tools_create_tool(tool_create, cookie_name=cookie_name)

Create a tool

Create a new tool (superadmin only).

### Example

* Api Key Authentication (APIKeyHeader):

```python
import neuland_hub_sdk
from neuland_hub_sdk.models.tool_create import ToolCreate
from neuland_hub_sdk.models.tool_out import ToolOut
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: APIKeyHeader
configuration.api_key['APIKeyHeader'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['APIKeyHeader'] = 'Bearer'

# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Tool(api_client)
    tool_create = neuland_hub_sdk.ToolCreate() # ToolCreate | 
    cookie_name = 'cookie_name_example' # str |  (optional)

    try:
        # Create a tool
        api_response = api_instance.tools_create_tool(tool_create, cookie_name=cookie_name)
        print("The response of Tool->tools_create_tool:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling Tool->tools_create_tool: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tool_create** | [**ToolCreate**](ToolCreate.md)|  | 
 **cookie_name** | **str**|  | [optional] 

### Return type

[**ToolOut**](ToolOut.md)

### Authorization

[APIKeyHeader](../README.md#APIKeyHeader)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |
**403** | Caller is not a superadmin. |  -  |
**422** | Invalid payload, an unknown or inactive category public_id, or a tool with the given name already exists. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **tools_delete_tool**
> tools_delete_tool(tool_id, cookie_name=cookie_name)

Delete a tool

Delete a tool (superadmin only).

### Example

* Api Key Authentication (APIKeyHeader):

```python
import neuland_hub_sdk
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: APIKeyHeader
configuration.api_key['APIKeyHeader'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['APIKeyHeader'] = 'Bearer'

# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Tool(api_client)
    tool_id = UUID('38400000-8cf0-11bd-b23e-10b96e4ef00d') # UUID | Public id of the tool to delete.
    cookie_name = 'cookie_name_example' # str |  (optional)

    try:
        # Delete a tool
        api_instance.tools_delete_tool(tool_id, cookie_name=cookie_name)
    except Exception as e:
        print("Exception when calling Tool->tools_delete_tool: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tool_id** | **UUID**| Public id of the tool to delete. | 
 **cookie_name** | **str**|  | [optional] 

### Return type

void (empty response body)

### Authorization

[APIKeyHeader](../README.md#APIKeyHeader)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |
**403** | Caller is not a superadmin. |  -  |
**404** | No tool exists with the given id. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **tools_update_tool**
> ToolOut tools_update_tool(tool_id, tool_update, cookie_name=cookie_name)

Update a tool

Update a tool's editable fields (superadmin only).

### Example

* Api Key Authentication (APIKeyHeader):

```python
import neuland_hub_sdk
from neuland_hub_sdk.models.tool_out import ToolOut
from neuland_hub_sdk.models.tool_update import ToolUpdate
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: APIKeyHeader
configuration.api_key['APIKeyHeader'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['APIKeyHeader'] = 'Bearer'

# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Tool(api_client)
    tool_id = UUID('38400000-8cf0-11bd-b23e-10b96e4ef00d') # UUID | Public id of the tool to update.
    tool_update = neuland_hub_sdk.ToolUpdate() # ToolUpdate | 
    cookie_name = 'cookie_name_example' # str |  (optional)

    try:
        # Update a tool
        api_response = api_instance.tools_update_tool(tool_id, tool_update, cookie_name=cookie_name)
        print("The response of Tool->tools_update_tool:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling Tool->tools_update_tool: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tool_id** | **UUID**| Public id of the tool to update. | 
 **tool_update** | [**ToolUpdate**](ToolUpdate.md)|  | 
 **cookie_name** | **str**|  | [optional] 

### Return type

[**ToolOut**](ToolOut.md)

### Authorization

[APIKeyHeader](../README.md#APIKeyHeader)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |
**403** | Caller is not a superadmin. |  -  |
**404** | No tool exists with the given id. |  -  |
**422** | Invalid payload, or an unknown or inactive category public_id. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

