# neuland_hub_sdk.AuthConnector

All URIs are relative to *https://api.your-domain.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**auth_get_credential_template**](AuthConnector.md#auth_get_credential_template) | **GET** /auth/connectors/{connector_id}/credential/template | Get connector credential template
[**auth_initiate_admin_consent**](AuthConnector.md#auth_initiate_admin_consent) | **GET** /auth/connectors/{connector_id}/consent/admin | Initiate admin connector consent
[**auth_initiate_consent**](AuthConnector.md#auth_initiate_consent) | **GET** /auth/connectors/{connector_id}/consent | Initiate connector consent
[**auth_list_connector_status**](AuthConnector.md#auth_list_connector_status) | **GET** /auth/connectors/status | List connector status
[**auth_oauth_callback**](AuthConnector.md#auth_oauth_callback) | **GET** /auth/connectors/callback | Connector OAuth callback
[**auth_revoke_consent**](AuthConnector.md#auth_revoke_consent) | **DELETE** /auth/connectors/{connector_id}/consent | Revoke connector consent
[**auth_set_admin_credential**](AuthConnector.md#auth_set_admin_credential) | **PUT** /auth/connectors/{connector_id}/credential/admin | Set the tenant-wide connector credential
[**auth_set_user_credential**](AuthConnector.md#auth_set_user_credential) | **PUT** /auth/connectors/{connector_id}/credential/user | Set the caller&#39;s connector credential
[**auth_update_connector**](AuthConnector.md#auth_update_connector) | **PATCH** /auth/connectors/{connector_id} | Update a connector
[**auth_update_oauth_client**](AuthConnector.md#auth_update_oauth_client) | **PATCH** /auth/connectors/oauth-clients/{oauth_client_id} | Update an OAuth client


# **auth_get_credential_template**
> CredentialTemplateOut auth_get_credential_template(connector_id, cookie_name=cookie_name)

Get connector credential template

The admin and/or user parts this connector needs and whether each is set.
Never returns stored secret values — only which fields are present.

### Example

* Api Key Authentication (APIKeyHeader):

```python
import neuland_hub_sdk
from neuland_hub_sdk.models.credential_template_out import CredentialTemplateOut
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: APIKeyHeader
configuration.api_key['APIKeyHeader'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['APIKeyHeader'] = 'Bearer'

# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.AuthConnector(api_client)
    connector_id = UUID('38400000-8cf0-11bd-b23e-10b96e4ef00d') # UUID | Public id of the connector whose credential is being accessed.
    cookie_name = 'cookie_name_example' # str |  (optional)

    try:
        # Get connector credential template
        api_response = api_instance.auth_get_credential_template(connector_id, cookie_name=cookie_name)
        print("The response of AuthConnector->auth_get_credential_template:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AuthConnector->auth_get_credential_template: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **connector_id** | **UUID**| Public id of the connector whose credential is being accessed. | 
 **cookie_name** | **str**|  | [optional] 

### Return type

[**CredentialTemplateOut**](CredentialTemplateOut.md)

### Authorization

[APIKeyHeader](../README.md#APIKeyHeader)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |
**404** | No connector or credential template exists for the given id. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_initiate_admin_consent**
> ConnectorConsentOut auth_initiate_admin_consent(connector_id, cookie_name=cookie_name)

Initiate admin connector consent

Start the admin consent flow for connectors that require organization-wide admin consent.

### Example

* Api Key Authentication (APIKeyHeader):

```python
import neuland_hub_sdk
from neuland_hub_sdk.models.connector_consent_out import ConnectorConsentOut
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: APIKeyHeader
configuration.api_key['APIKeyHeader'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['APIKeyHeader'] = 'Bearer'

# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.AuthConnector(api_client)
    connector_id = UUID('38400000-8cf0-11bd-b23e-10b96e4ef00d') # UUID | Public id of the connector to consent to.
    cookie_name = 'cookie_name_example' # str |  (optional)

    try:
        # Initiate admin connector consent
        api_response = api_instance.auth_initiate_admin_consent(connector_id, cookie_name=cookie_name)
        print("The response of AuthConnector->auth_initiate_admin_consent:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AuthConnector->auth_initiate_admin_consent: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **connector_id** | **UUID**| Public id of the connector to consent to. | 
 **cookie_name** | **str**|  | [optional] 

### Return type

[**ConnectorConsentOut**](ConnectorConsentOut.md)

### Authorization

[APIKeyHeader](../README.md#APIKeyHeader)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |
**403** | Administrator privileges required. |  -  |
**404** | No connector or OAuth client exists for the given id. |  -  |
**503** | The OAuth provider has no admin consent URL or is misconfigured. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_initiate_consent**
> ConnectorConsentOut auth_initiate_consent(connector_id, return_url=return_url, redirect=redirect, cookie_name=cookie_name)

Initiate connector consent

Initiate OAuth consent flow for a connector. Returns the provider consent
URL as JSON, or a 302 redirect when redirect=true.

### Example

* Api Key Authentication (APIKeyHeader):

```python
import neuland_hub_sdk
from neuland_hub_sdk.models.connector_consent_out import ConnectorConsentOut
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: APIKeyHeader
configuration.api_key['APIKeyHeader'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['APIKeyHeader'] = 'Bearer'

# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.AuthConnector(api_client)
    connector_id = UUID('38400000-8cf0-11bd-b23e-10b96e4ef00d') # UUID | Public id of the connector to consent to.
    return_url = 'return_url_example' # str | URL to return the user to after consent. (optional)
    redirect = False # bool | If true, return 302 redirect instead of JSON (optional) (default to False)
    cookie_name = 'cookie_name_example' # str |  (optional)

    try:
        # Initiate connector consent
        api_response = api_instance.auth_initiate_consent(connector_id, return_url=return_url, redirect=redirect, cookie_name=cookie_name)
        print("The response of AuthConnector->auth_initiate_consent:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AuthConnector->auth_initiate_consent: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **connector_id** | **UUID**| Public id of the connector to consent to. | 
 **return_url** | **str**| URL to return the user to after consent. | [optional] 
 **redirect** | **bool**| If true, return 302 redirect instead of JSON | [optional] [default to False]
 **cookie_name** | **str**|  | [optional] 

### Return type

[**ConnectorConsentOut**](ConnectorConsentOut.md)

### Authorization

[APIKeyHeader](../README.md#APIKeyHeader)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |
**404** | No connector or OAuth client exists for the given id. |  -  |
**503** | The OAuth provider is misconfigured. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_list_connector_status**
> List[ConnectorStatusOut] auth_list_connector_status(cookie_name=cookie_name)

List connector status

List connectors available to the user's tenant with their per-user consent status.

### Example

* Api Key Authentication (APIKeyHeader):

```python
import neuland_hub_sdk
from neuland_hub_sdk.models.connector_status_out import ConnectorStatusOut
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: APIKeyHeader
configuration.api_key['APIKeyHeader'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['APIKeyHeader'] = 'Bearer'

# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.AuthConnector(api_client)
    cookie_name = 'cookie_name_example' # str |  (optional)

    try:
        # List connector status
        api_response = api_instance.auth_list_connector_status(cookie_name=cookie_name)
        print("The response of AuthConnector->auth_list_connector_status:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AuthConnector->auth_list_connector_status: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cookie_name** | **str**|  | [optional] 

### Return type

[**List[ConnectorStatusOut]**](ConnectorStatusOut.md)

### Authorization

[APIKeyHeader](../README.md#APIKeyHeader)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |
**404** | The current user no longer exists. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_oauth_callback**
> object auth_oauth_callback(state=state, code=code, error=error, error_description=error_description, error_subcode=error_subcode)

Connector OAuth callback

Handle the provider redirect after user consent and persist the granted connector tokens.

### Example


```python
import neuland_hub_sdk
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)


# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.AuthConnector(api_client)
    state = 'state_example' # str | Opaque state token issued when consent was initiated. (optional)
    code = 'code_example' # str |  (optional)
    error = 'error_example' # str |  (optional)
    error_description = 'error_description_example' # str |  (optional)
    error_subcode = 'error_subcode_example' # str |  (optional)

    try:
        # Connector OAuth callback
        api_response = api_instance.auth_oauth_callback(state=state, code=code, error=error, error_description=error_description, error_subcode=error_subcode)
        print("The response of AuthConnector->auth_oauth_callback:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AuthConnector->auth_oauth_callback: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **state** | **str**| Opaque state token issued when consent was initiated. | [optional] 
 **code** | **str**|  | [optional] 
 **error** | **str**|  | [optional] 
 **error_description** | **str**|  | [optional] 
 **error_subcode** | **str**|  | [optional] 

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**403** | The provider granted insufficient scopes for the requested capabilities. |  -  |
**404** | No connector or OAuth client exists for the consent state. |  -  |
**503** | Token exchange with the OAuth provider failed. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_revoke_consent**
> auth_revoke_consent(connector_id, cookie_name=cookie_name)

Revoke connector consent

Disconnect a connector for the caller: revoke OAuth consent for OAuth
connectors, or clear the caller's own credential for non-OAuth ones.

### Example

* Api Key Authentication (APIKeyHeader):

```python
import neuland_hub_sdk
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: APIKeyHeader
configuration.api_key['APIKeyHeader'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['APIKeyHeader'] = 'Bearer'

# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.AuthConnector(api_client)
    connector_id = UUID('38400000-8cf0-11bd-b23e-10b96e4ef00d') # UUID | Public id of the connector to revoke consent for.
    cookie_name = 'cookie_name_example' # str |  (optional)

    try:
        # Revoke connector consent
        api_instance.auth_revoke_consent(connector_id, cookie_name=cookie_name)
    except Exception as e:
        print("Exception when calling AuthConnector->auth_revoke_consent: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **connector_id** | **UUID**| Public id of the connector to revoke consent for. | 
 **cookie_name** | **str**|  | [optional] 

### Return type

void (empty response body)

### Authorization

[APIKeyHeader](../README.md#APIKeyHeader)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_set_admin_credential**
> auth_set_admin_credential(connector_id, credential_in, cookie_name=cookie_name)

Set the tenant-wide connector credential

Store the tenant-wide (admin) credential fields. Admin only.

### Example

* Api Key Authentication (APIKeyHeader):

```python
import neuland_hub_sdk
from neuland_hub_sdk.models.credential_in import CredentialIn
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: APIKeyHeader
configuration.api_key['APIKeyHeader'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['APIKeyHeader'] = 'Bearer'

# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.AuthConnector(api_client)
    connector_id = UUID('38400000-8cf0-11bd-b23e-10b96e4ef00d') # UUID | Public id of the connector whose credential is being accessed.
    credential_in = neuland_hub_sdk.CredentialIn() # CredentialIn | 
    cookie_name = 'cookie_name_example' # str |  (optional)

    try:
        # Set the tenant-wide connector credential
        api_instance.auth_set_admin_credential(connector_id, credential_in, cookie_name=cookie_name)
    except Exception as e:
        print("Exception when calling AuthConnector->auth_set_admin_credential: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **connector_id** | **UUID**| Public id of the connector whose credential is being accessed. | 
 **credential_in** | [**CredentialIn**](CredentialIn.md)|  | 
 **cookie_name** | **str**|  | [optional] 

### Return type

void (empty response body)

### Authorization

[APIKeyHeader](../README.md#APIKeyHeader)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |
**403** | Administrator privileges required. |  -  |
**404** | No connector/template exists, or it has no admin credential fields. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_set_user_credential**
> auth_set_user_credential(connector_id, credential_in, cookie_name=cookie_name)

Set the caller's connector credential

Store the caller's per-user credential fields.

### Example

* Api Key Authentication (APIKeyHeader):

```python
import neuland_hub_sdk
from neuland_hub_sdk.models.credential_in import CredentialIn
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: APIKeyHeader
configuration.api_key['APIKeyHeader'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['APIKeyHeader'] = 'Bearer'

# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.AuthConnector(api_client)
    connector_id = UUID('38400000-8cf0-11bd-b23e-10b96e4ef00d') # UUID | Public id of the connector whose credential is being accessed.
    credential_in = neuland_hub_sdk.CredentialIn() # CredentialIn | 
    cookie_name = 'cookie_name_example' # str |  (optional)

    try:
        # Set the caller's connector credential
        api_instance.auth_set_user_credential(connector_id, credential_in, cookie_name=cookie_name)
    except Exception as e:
        print("Exception when calling AuthConnector->auth_set_user_credential: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **connector_id** | **UUID**| Public id of the connector whose credential is being accessed. | 
 **credential_in** | [**CredentialIn**](CredentialIn.md)|  | 
 **cookie_name** | **str**|  | [optional] 

### Return type

void (empty response body)

### Authorization

[APIKeyHeader](../README.md#APIKeyHeader)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |
**404** | No connector/template exists, or it has no per-user credential fields. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_update_connector**
> Connector auth_update_connector(connector_id, connector_update, cookie_name=cookie_name)

Update a connector

Update a connector (superadmin only).

### Example

* Api Key Authentication (APIKeyHeader):

```python
import neuland_hub_sdk
from neuland_hub_sdk.models.connector import Connector
from neuland_hub_sdk.models.connector_update import ConnectorUpdate
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: APIKeyHeader
configuration.api_key['APIKeyHeader'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['APIKeyHeader'] = 'Bearer'

# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.AuthConnector(api_client)
    connector_id = UUID('38400000-8cf0-11bd-b23e-10b96e4ef00d') # UUID | Public id of the connector to update.
    connector_update = neuland_hub_sdk.ConnectorUpdate() # ConnectorUpdate | 
    cookie_name = 'cookie_name_example' # str |  (optional)

    try:
        # Update a connector
        api_response = api_instance.auth_update_connector(connector_id, connector_update, cookie_name=cookie_name)
        print("The response of AuthConnector->auth_update_connector:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AuthConnector->auth_update_connector: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **connector_id** | **UUID**| Public id of the connector to update. | 
 **connector_update** | [**ConnectorUpdate**](ConnectorUpdate.md)|  | 
 **cookie_name** | **str**|  | [optional] 

### Return type

[**Connector**](Connector.md)

### Authorization

[APIKeyHeader](../README.md#APIKeyHeader)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |
**403** | Platform operator (superadmin) privileges required. |  -  |
**404** | No connector exists with the given id. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_update_oauth_client**
> OAuthClient auth_update_oauth_client(oauth_client_id, o_auth_client_update, cookie_name=cookie_name)

Update an OAuth client

Update an OAuth client (superadmin only).

### Example

* Api Key Authentication (APIKeyHeader):

```python
import neuland_hub_sdk
from neuland_hub_sdk.models.o_auth_client import OAuthClient
from neuland_hub_sdk.models.o_auth_client_update import OAuthClientUpdate
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: APIKeyHeader
configuration.api_key['APIKeyHeader'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['APIKeyHeader'] = 'Bearer'

# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.AuthConnector(api_client)
    oauth_client_id = UUID('38400000-8cf0-11bd-b23e-10b96e4ef00d') # UUID | Public id of the OAuth client to update.
    o_auth_client_update = neuland_hub_sdk.OAuthClientUpdate() # OAuthClientUpdate | 
    cookie_name = 'cookie_name_example' # str |  (optional)

    try:
        # Update an OAuth client
        api_response = api_instance.auth_update_oauth_client(oauth_client_id, o_auth_client_update, cookie_name=cookie_name)
        print("The response of AuthConnector->auth_update_oauth_client:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AuthConnector->auth_update_oauth_client: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **oauth_client_id** | **UUID**| Public id of the OAuth client to update. | 
 **o_auth_client_update** | [**OAuthClientUpdate**](OAuthClientUpdate.md)|  | 
 **cookie_name** | **str**|  | [optional] 

### Return type

[**OAuthClient**](OAuthClient.md)

### Authorization

[APIKeyHeader](../README.md#APIKeyHeader)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |
**403** | Platform operator (superadmin) privileges required. |  -  |
**404** | No OAuth client exists with the given id. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

