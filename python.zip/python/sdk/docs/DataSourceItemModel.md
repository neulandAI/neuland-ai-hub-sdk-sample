# DataSourceItemModel

A file or folder item from a data source, normalized across providers.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Provider item id. | 
**web_url** | **str** | URL to open the item in the source application. | 
**drive_id** | **str** | Id of the drive containing the item. | 
**site_id** | **str** |  | 
**parent_folder_id** | **str** | Id of the parent folder, or &#39;root&#39;. | 
**parent_path** | **str** |  | 
**name** | **str** |  | 
**description** | **str** |  | 
**size** | **int** |  | 
**last_modified_date_time** | **datetime** |  | 
**mimetype** | **str** |  | 
**folder** | [**DataSourceFolderModel**](DataSourceFolderModel.md) |  | 
**imported** | **bool** |  | [optional] 
**imported_count** | **int** |  | [optional] 

## Example

```python
from neuland_hub_sdk.models.data_source_item_model import DataSourceItemModel

# TODO update the JSON string below
json = "{}"
# create an instance of DataSourceItemModel from a JSON string
data_source_item_model_instance = DataSourceItemModel.from_json(json)
# print the JSON string representation of the object
print(DataSourceItemModel.to_json())

# convert the object into a dict
data_source_item_model_dict = data_source_item_model_instance.to_dict()
# create an instance of DataSourceItemModel from a dict
data_source_item_model_from_dict = DataSourceItemModel.from_dict(data_source_item_model_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


