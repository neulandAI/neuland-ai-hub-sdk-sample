# NeulandAssistantsTaggingOut

A tagging, identifying the tag and taggable resource by public id.  `tag_id`/`taggable_id` (int) are kept alongside the public ids (dual-key — both are returned permanently); external clients should reference `tag_public_id`/`taggable_public_id`.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tag_id** | **int** | Internal id of the tag (deprecated; use tag_public_id). | 
**tag_public_id** | **UUID** | Public id of the tag being applied. | 
**taggable_type** | **str** | Resource type this tag is attached to. | 
**taggable_id** | **int** | Internal id of the resource (deprecated; use taggable_public_id). | 
**taggable_public_id** | **UUID** | Public id of the tagged resource. | 

## Example

```python
from neuland_hub_sdk.models.neuland_assistants_tagging_out import NeulandAssistantsTaggingOut

# TODO update the JSON string below
json = "{}"
# create an instance of NeulandAssistantsTaggingOut from a JSON string
neuland_assistants_tagging_out_instance = NeulandAssistantsTaggingOut.from_json(json)
# print the JSON string representation of the object
print(NeulandAssistantsTaggingOut.to_json())

# convert the object into a dict
neuland_assistants_tagging_out_dict = neuland_assistants_tagging_out_instance.to_dict()
# create an instance of NeulandAssistantsTaggingOut from a dict
neuland_assistants_tagging_out_from_dict = NeulandAssistantsTaggingOut.from_dict(neuland_assistants_tagging_out_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


