# TenantLLM

Availability rows for tenant-enabled LLM models.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **datetime** | UTC timestamp when the record was created. | [optional] 
**updated_at** | **datetime** | UTC timestamp when the record was last updated. | [optional] 
**creator_user_id** | **int** |  | [optional] 
**updater_user_id** | **int** |  | [optional] 
**tenant_id** | **int** | ID of the tenant the LLM is enabled for. | 
**llm_catalog_id** | **int** | ID of the LLM catalog entry enabled for the tenant. | 

## Example

```python
from neuland_hub_sdk.models.tenant_llm import TenantLLM

# TODO update the JSON string below
json = "{}"
# create an instance of TenantLLM from a JSON string
tenant_llm_instance = TenantLLM.from_json(json)
# print the JSON string representation of the object
print(TenantLLM.to_json())

# convert the object into a dict
tenant_llm_dict = tenant_llm_instance.to_dict()
# create an instance of TenantLLM from a dict
tenant_llm_from_dict = TenantLLM.from_dict(tenant_llm_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


