# CostCompletionTokens

Cost per completion token in the billing currency.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from neuland_hub_sdk.models.cost_completion_tokens import CostCompletionTokens

# TODO update the JSON string below
json = "{}"
# create an instance of CostCompletionTokens from a JSON string
cost_completion_tokens_instance = CostCompletionTokens.from_json(json)
# print the JSON string representation of the object
print(CostCompletionTokens.to_json())

# convert the object into a dict
cost_completion_tokens_dict = cost_completion_tokens_instance.to_dict()
# create an instance of CostCompletionTokens from a dict
cost_completion_tokens_from_dict = CostCompletionTokens.from_dict(cost_completion_tokens_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


