# UsageCostRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**granularity** | **str** | Aggregation window; &#39;custom&#39; requires date_start and date_end. | [optional] [default to 'monthly']
**date_start** | **datetime** |  | [optional] 
**date_end** | **datetime** |  | [optional] 
**source** | **str** |  | [optional] 
**model** | **str** |  | [optional] 
**provider** | **str** |  | [optional] 

## Example

```python
from neuland_hub_sdk.models.usage_cost_request import UsageCostRequest

# TODO update the JSON string below
json = "{}"
# create an instance of UsageCostRequest from a JSON string
usage_cost_request_instance = UsageCostRequest.from_json(json)
# print the JSON string representation of the object
print(UsageCostRequest.to_json())

# convert the object into a dict
usage_cost_request_dict = usage_cost_request_instance.to_dict()
# create an instance of UsageCostRequest from a dict
usage_cost_request_from_dict = UsageCostRequest.from_dict(usage_cost_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


