# CostCompletionTokens1

Cost per completion token in the billing currency.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from neuland_hub_sdk.models.cost_completion_tokens1 import CostCompletionTokens1

# TODO update the JSON string below
json = "{}"
# create an instance of CostCompletionTokens1 from a JSON string
cost_completion_tokens1_instance = CostCompletionTokens1.from_json(json)
# print the JSON string representation of the object
print(CostCompletionTokens1.to_json())

# convert the object into a dict
cost_completion_tokens1_dict = cost_completion_tokens1_instance.to_dict()
# create an instance of CostCompletionTokens1 from a dict
cost_completion_tokens1_from_dict = CostCompletionTokens1.from_dict(cost_completion_tokens1_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


