# neuland_hub_sdk.Auth

All URIs are relative to *https://api.your-domain.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**auth_confirm_email**](Auth.md#auth_confirm_email) | **GET** /auth/confirm-email | Confirm an email address
[**auth_exchange_token**](Auth.md#auth_exchange_token) | **POST** /auth/exchange/token | Exchange for a service token
[**auth_get_entra_groups**](Auth.md#auth_get_entra_groups) | **GET** /auth/entra/groups | Get Entra group names
[**auth_get_entra_scopes**](Auth.md#auth_get_entra_scopes) | **GET** /auth/entra/scopes | List Entra scopes
[**auth_login**](Auth.md#auth_login) | **POST** /auth/token | Log in
[**auth_logout**](Auth.md#auth_logout) | **POST** /auth/logout | Log out
[**auth_request_password_reset**](Auth.md#auth_request_password_reset) | **POST** /auth/request-password-reset | Request a password reset
[**auth_reset_password**](Auth.md#auth_reset_password) | **POST** /auth/reset-password | Complete a password reset
[**auth_reset_password_form**](Auth.md#auth_reset_password_form) | **GET** /auth/reset-password | Password reset HTML form
[**auth_search_entra_groups**](Auth.md#auth_search_entra_groups) | **GET** /auth/entra/groups/search | Search Entra directory groups
[**auth_send_email_confirmation**](Auth.md#auth_send_email_confirmation) | **POST** /auth/send-email-confirmation | Send an email confirmation
[**auth_sso_exchange**](Auth.md#auth_sso_exchange) | **POST** /auth/sso/{slug}/{provider}/exchange | Complete an SSO login
[**auth_sso_init**](Auth.md#auth_sso_init) | **GET** /auth/sso/{slug}/{provider}/init | Start an SSO login
[**auth_sso_resolve**](Auth.md#auth_sso_resolve) | **GET** /auth/sso/resolve | Resolve SSO providers for an email


# **auth_confirm_email**
> object auth_confirm_email(token, accept=accept)

Confirm an email address

Confirm a user's email address (or pending email change) using a token from the email link.

### Example


```python
import neuland_hub_sdk
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)


# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Auth(api_client)
    token = 'token_example' # str | JWT token from confirmation email
    accept = 'accept_example' # str |  (optional)

    try:
        # Confirm an email address
        api_response = api_instance.auth_confirm_email(token, accept=accept)
        print("The response of Auth->auth_confirm_email:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling Auth->auth_confirm_email: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **token** | **str**| JWT token from confirmation email | 
 **accept** | **str**|  | [optional] 

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**400** | Invalid or expired confirmation link. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_exchange_token**
> str auth_exchange_token(app_id)

Exchange for a service token

Exchange the caller's token for a service token scoped to an AI application.

### Example


```python
import neuland_hub_sdk
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)


# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Auth(api_client)
    app_id = UUID('38400000-8cf0-11bd-b23e-10b96e4ef00d') # UUID | Public id of the AI application to scope the token to.

    try:
        # Exchange for a service token
        api_response = api_instance.auth_exchange_token(app_id)
        print("The response of Auth->auth_exchange_token:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling Auth->auth_exchange_token: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **app_id** | **UUID**| Public id of the AI application to scope the token to. | 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |
**404** | No application exists with the given public id. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_get_entra_groups**
> Dict[str, ResponseAuthGetEntraGroupsValue] auth_get_entra_groups()

Get Entra group names

Resolve Azure Entra group display names for the current user's groups.

### Example


```python
import neuland_hub_sdk
from neuland_hub_sdk.models.response_auth_get_entra_groups_value import ResponseAuthGetEntraGroupsValue
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)


# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Auth(api_client)

    try:
        # Get Entra group names
        api_response = api_instance.auth_get_entra_groups()
        print("The response of Auth->auth_get_entra_groups:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling Auth->auth_get_entra_groups: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**Dict[str, ResponseAuthGetEntraGroupsValue]**](ResponseAuthGetEntraGroupsValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_get_entra_scopes**
> List[Optional[str]] auth_get_entra_scopes()

List Entra scopes

List the Azure Entra OAuth scopes the platform requests.

### Example


```python
import neuland_hub_sdk
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)


# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Auth(api_client)

    try:
        # List Entra scopes
        api_response = api_instance.auth_get_entra_scopes()
        print("The response of Auth->auth_get_entra_scopes:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling Auth->auth_get_entra_scopes: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

**List[Optional[str]]**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_login**
> TokenOut auth_login(username, password, user_agent=user_agent, x_real_ip=x_real_ip, x_forwarded_for=x_forwarded_for, x_client_ip=x_client_ip, session_id=session_id, grant_type=grant_type, scope=scope, client_id=client_id, client_secret=client_secret)

Log in

Authenticate with username and password and return an access token.

### Example


```python
import neuland_hub_sdk
from neuland_hub_sdk.models.token_out import TokenOut
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)


# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Auth(api_client)
    username = 'username_example' # str | 
    password = 'password_example' # str | 
    user_agent = 'user_agent_example' # str |  (optional)
    x_real_ip = 'x_real_ip_example' # str |  (optional)
    x_forwarded_for = 'x_forwarded_for_example' # str |  (optional)
    x_client_ip = 'x_client_ip_example' # str |  (optional)
    session_id = 56 # int |  (optional)
    grant_type = 'grant_type_example' # str |  (optional)
    scope = '' # str |  (optional) (default to '')
    client_id = 'client_id_example' # str |  (optional)
    client_secret = 'client_secret_example' # str |  (optional)

    try:
        # Log in
        api_response = api_instance.auth_login(username, password, user_agent=user_agent, x_real_ip=x_real_ip, x_forwarded_for=x_forwarded_for, x_client_ip=x_client_ip, session_id=session_id, grant_type=grant_type, scope=scope, client_id=client_id, client_secret=client_secret)
        print("The response of Auth->auth_login:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling Auth->auth_login: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**|  | 
 **password** | **str**|  | 
 **user_agent** | **str**|  | [optional] 
 **x_real_ip** | **str**|  | [optional] 
 **x_forwarded_for** | **str**|  | [optional] 
 **x_client_ip** | **str**|  | [optional] 
 **session_id** | **int**|  | [optional] 
 **grant_type** | **str**|  | [optional] 
 **scope** | **str**|  | [optional] [default to &#39;&#39;]
 **client_id** | **str**|  | [optional] 
 **client_secret** | **str**|  | [optional] 

### Return type

[**TokenOut**](TokenOut.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**401** | Invalid email or password. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_logout**
> object auth_logout()

Log out

Revoke the current session so its token can no longer authenticate.

### Example


```python
import neuland_hub_sdk
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)


# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Auth(api_client)

    try:
        # Log out
        api_response = api_instance.auth_logout()
        print("The response of Auth->auth_logout:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling Auth->auth_logout: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |
**404** | Session not found. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_request_password_reset**
> auth_request_password_reset(password_reset_request_in, origin=origin)

Request a password reset

Send a password reset link if the account exists; always succeeds to prevent enumeration.

### Example


```python
import neuland_hub_sdk
from neuland_hub_sdk.models.password_reset_request_in import PasswordResetRequestIn
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)


# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Auth(api_client)
    password_reset_request_in = neuland_hub_sdk.PasswordResetRequestIn() # PasswordResetRequestIn | 
    origin = 'origin_example' # str |  (optional)

    try:
        # Request a password reset
        api_instance.auth_request_password_reset(password_reset_request_in, origin=origin)
    except Exception as e:
        print("Exception when calling Auth->auth_request_password_reset: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **password_reset_request_in** | [**PasswordResetRequestIn**](PasswordResetRequestIn.md)|  | 
 **origin** | **str**|  | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | Successful Response |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_reset_password**
> auth_reset_password(token)

Complete a password reset

Validate the reset token, set the new password, and revoke all of the user's sessions.

### Example


```python
import neuland_hub_sdk
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)


# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Auth(api_client)
    token = 'token_example' # str | Password reset JWT token

    try:
        # Complete a password reset
        api_instance.auth_reset_password(token)
    except Exception as e:
        print("Exception when calling Auth->auth_reset_password: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **token** | **str**| Password reset JWT token | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | Successful Response |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_reset_password_form**
> str auth_reset_password_form(token)

Password reset HTML form

Render the fallback HTML password-reset form for when no frontend is available.

### Example


```python
import neuland_hub_sdk
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)


# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Auth(api_client)
    token = 'token_example' # str | Password reset JWT token

    try:
        # Password reset HTML form
        api_response = api_instance.auth_reset_password_form(token)
        print("The response of Auth->auth_reset_password_form:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling Auth->auth_reset_password_form: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **token** | **str**| Password reset JWT token | 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/html, application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_search_entra_groups**
> Dict[str, object] auth_search_entra_groups(q=q, cursor=cursor, cookie_name=cookie_name)

Search Entra directory groups

Search/browse Entra directory groups (delegated) for binding to a HUB group.

### Example

* Api Key Authentication (APIKeyHeader):

```python
import neuland_hub_sdk
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: APIKeyHeader
configuration.api_key['APIKeyHeader'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['APIKeyHeader'] = 'Bearer'

# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Auth(api_client)
    q = 'q_example' # str | Name/description search; empty browses alphabetically (optional)
    cursor = 'cursor_example' # str | Page cursor from a prior response's `next` (optional)
    cookie_name = 'cookie_name_example' # str |  (optional)

    try:
        # Search Entra directory groups
        api_response = api_instance.auth_search_entra_groups(q=q, cursor=cursor, cookie_name=cookie_name)
        print("The response of Auth->auth_search_entra_groups:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling Auth->auth_search_entra_groups: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **q** | **str**| Name/description search; empty browses alphabetically | [optional] 
 **cursor** | **str**| Page cursor from a prior response&#39;s &#x60;next&#x60; | [optional] 
 **cookie_name** | **str**|  | [optional] 

### Return type

**Dict[str, object]**

### Authorization

[APIKeyHeader](../README.md#APIKeyHeader)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**401** | Missing or invalid authentication, or not an Azure Entra session. |  -  |
**403** | Administrator privileges required. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_send_email_confirmation**
> auth_send_email_confirmation(cookie_name=cookie_name)

Send an email confirmation

Send a confirmation email to the current user unless their email is already verified.

### Example

* Api Key Authentication (APIKeyHeader):

```python
import neuland_hub_sdk
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: APIKeyHeader
configuration.api_key['APIKeyHeader'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['APIKeyHeader'] = 'Bearer'

# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Auth(api_client)
    cookie_name = 'cookie_name_example' # str |  (optional)

    try:
        # Send an email confirmation
        api_instance.auth_send_email_confirmation(cookie_name=cookie_name)
    except Exception as e:
        print("Exception when calling Auth->auth_send_email_confirmation: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cookie_name** | **str**|  | [optional] 

### Return type

void (empty response body)

### Authorization

[APIKeyHeader](../README.md#APIKeyHeader)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_sso_exchange**
> TokenOut auth_sso_exchange(slug, provider, sso_exchange_in, user_agent=user_agent, x_real_ip=x_real_ip, x_forwarded_for=x_forwarded_for, x_client_ip=x_client_ip)

Complete an SSO login

Exchange an IdP authorization code (with the signed state from init)
for a Hub access token. Stateless: state is an HMAC-signed JWT, not a cookie.

### Example


```python
import neuland_hub_sdk
from neuland_hub_sdk.models.sso_exchange_in import SsoExchangeIn
from neuland_hub_sdk.models.token_out import TokenOut
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)


# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Auth(api_client)
    slug = 'slug_example' # str | Tenant routing slug from sso/resolve.
    provider = 'provider_example' # str | OAuth provider key, e.g. 'microsoft'.
    sso_exchange_in = neuland_hub_sdk.SsoExchangeIn() # SsoExchangeIn | 
    user_agent = 'user_agent_example' # str |  (optional)
    x_real_ip = 'x_real_ip_example' # str |  (optional)
    x_forwarded_for = 'x_forwarded_for_example' # str |  (optional)
    x_client_ip = 'x_client_ip_example' # str |  (optional)

    try:
        # Complete an SSO login
        api_response = api_instance.auth_sso_exchange(slug, provider, sso_exchange_in, user_agent=user_agent, x_real_ip=x_real_ip, x_forwarded_for=x_forwarded_for, x_client_ip=x_client_ip)
        print("The response of Auth->auth_sso_exchange:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling Auth->auth_sso_exchange: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slug** | **str**| Tenant routing slug from sso/resolve. | 
 **provider** | **str**| OAuth provider key, e.g. &#39;microsoft&#39;. | 
 **sso_exchange_in** | [**SsoExchangeIn**](SsoExchangeIn.md)|  | 
 **user_agent** | **str**|  | [optional] 
 **x_real_ip** | **str**|  | [optional] 
 **x_forwarded_for** | **str**|  | [optional] 
 **x_client_ip** | **str**|  | [optional] 

### Return type

[**TokenOut**](TokenOut.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**400** | Unknown provider or provider does not support SSO login. |  -  |
**403** | Invalid, expired, or mismatched SSO state token. |  -  |
**404** | No tenant matches the slug, or the provider is not configured. |  -  |
**503** | Token exchange with the identity provider failed. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_sso_init**
> SsoInitOut auth_sso_init(slug, provider)

Start an SSO login

Return the IdP authorize URL + signed state token. No cookies, no redirect.
Frontend uses the response to redirect the browser to the IdP itself.

### Example


```python
import neuland_hub_sdk
from neuland_hub_sdk.models.sso_init_out import SsoInitOut
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)


# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Auth(api_client)
    slug = 'slug_example' # str | Tenant routing slug from sso/resolve.
    provider = 'provider_example' # str | OAuth provider key, e.g. 'microsoft'.

    try:
        # Start an SSO login
        api_response = api_instance.auth_sso_init(slug, provider)
        print("The response of Auth->auth_sso_init:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling Auth->auth_sso_init: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slug** | **str**| Tenant routing slug from sso/resolve. | 
 **provider** | **str**| OAuth provider key, e.g. &#39;microsoft&#39;. | 

### Return type

[**SsoInitOut**](SsoInitOut.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**400** | Unknown provider or provider does not support SSO login. |  -  |
**404** | No tenant matches the slug, or the provider is not configured. |  -  |
**503** | SSO is not configured for this tenant. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **auth_sso_resolve**
> SsoResolveOut auth_sso_resolve(email)

Resolve SSO providers for an email

Pre-login step: resolve a tenant from the email's domain, falling back to
the exact (unique) email, and return the routing slug and SSO providers.

### Example


```python
import neuland_hub_sdk
from neuland_hub_sdk.models.sso_resolve_out import SsoResolveOut
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)


# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Auth(api_client)
    email = 'email_example' # str | Work email whose domain identifies the tenant.

    try:
        # Resolve SSO providers for an email
        api_response = api_instance.auth_sso_resolve(email)
        print("The response of Auth->auth_sso_resolve:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling Auth->auth_sso_resolve: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **email** | **str**| Work email whose domain identifies the tenant. | 

### Return type

[**SsoResolveOut**](SsoResolveOut.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**404** | No tenant is registered for the email&#39;s domain. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

