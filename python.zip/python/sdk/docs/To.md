# To

Recipient email address(es)

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from neuland_hub_sdk.models.to import To

# TODO update the JSON string below
json = "{}"
# create an instance of To from a JSON string
to_instance = To.from_json(json)
# print the JSON string representation of the object
print(To.to_json())

# convert the object into a dict
to_dict = to_instance.to_dict()
# create an instance of To from a dict
to_from_dict = To.from_dict(to_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


