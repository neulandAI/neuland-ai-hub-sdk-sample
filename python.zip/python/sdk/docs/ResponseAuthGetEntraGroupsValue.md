# ResponseAuthGetEntraGroupsValue


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from neuland_hub_sdk.models.response_auth_get_entra_groups_value import ResponseAuthGetEntraGroupsValue

# TODO update the JSON string below
json = "{}"
# create an instance of ResponseAuthGetEntraGroupsValue from a JSON string
response_auth_get_entra_groups_value_instance = ResponseAuthGetEntraGroupsValue.from_json(json)
# print the JSON string representation of the object
print(ResponseAuthGetEntraGroupsValue.to_json())

# convert the object into a dict
response_auth_get_entra_groups_value_dict = response_auth_get_entra_groups_value_instance.to_dict()
# create an instance of ResponseAuthGetEntraGroupsValue from a dict
response_auth_get_entra_groups_value_from_dict = ResponseAuthGetEntraGroupsValue.from_dict(response_auth_get_entra_groups_value_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


