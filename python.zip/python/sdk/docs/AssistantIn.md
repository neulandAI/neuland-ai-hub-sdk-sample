# AssistantIn


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Display name of the assistant. | 
**model** | **str** |  | [optional] 
**avatar** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**description_show_in_chat** | **bool** | Whether to show the description inside the chat UI. | [optional] [default to False]
**predefined_prompts** | **List[str]** |  | [optional] 
**instructions** | **str** |  | [optional] 
**temperature** | **float** |  | [optional] 
**similarity_top_k** | **float** |  | [optional] 
**input_type** | [**AssistantInputTypeEnum**](AssistantInputTypeEnum.md) | Input mode: free-text prompt or structured form. | [optional] 
**form_fields** | [**List[FormField]**](FormField.md) |  | [optional] 

## Example

```python
from neuland_hub_sdk.models.assistant_in import AssistantIn

# TODO update the JSON string below
json = "{}"
# create an instance of AssistantIn from a JSON string
assistant_in_instance = AssistantIn.from_json(json)
# print the JSON string representation of the object
print(AssistantIn.to_json())

# convert the object into a dict
assistant_in_dict = assistant_in_instance.to_dict()
# create an instance of AssistantIn from a dict
assistant_in_from_dict = AssistantIn.from_dict(assistant_in_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


