# ChatToolSettingsUpdate

Request schema for updating a single chat tool setting

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **bool** | Whether the tool is enabled for the chat. | 

## Example

```python
from neuland_hub_sdk.models.chat_tool_settings_update import ChatToolSettingsUpdate

# TODO update the JSON string below
json = "{}"
# create an instance of ChatToolSettingsUpdate from a JSON string
chat_tool_settings_update_instance = ChatToolSettingsUpdate.from_json(json)
# print the JSON string representation of the object
print(ChatToolSettingsUpdate.to_json())

# convert the object into a dict
chat_tool_settings_update_dict = chat_tool_settings_update_instance.to_dict()
# create an instance of ChatToolSettingsUpdate from a dict
chat_tool_settings_update_from_dict = ChatToolSettingsUpdate.from_dict(chat_tool_settings_update_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


