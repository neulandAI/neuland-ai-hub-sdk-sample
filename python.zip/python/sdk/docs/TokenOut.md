# TokenOut


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_token** | **str** | Signed JWT access token to send as a Bearer credential. | 
**token_type** | **str** | Token scheme to use in the Authorization header. | 

## Example

```python
from neuland_hub_sdk.models.token_out import TokenOut

# TODO update the JSON string below
json = "{}"
# create an instance of TokenOut from a JSON string
token_out_instance = TokenOut.from_json(json)
# print the JSON string representation of the object
print(TokenOut.to_json())

# convert the object into a dict
token_out_dict = token_out_instance.to_dict()
# create an instance of TokenOut from a dict
token_out_from_dict = TokenOut.from_dict(token_out_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


