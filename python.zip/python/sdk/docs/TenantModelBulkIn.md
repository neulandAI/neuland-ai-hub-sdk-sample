# TenantModelBulkIn


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**all** | **bool** |  | [optional] 
**tenant_ids** | **List[UUID]** |  | [optional] 

## Example

```python
from neuland_hub_sdk.models.tenant_model_bulk_in import TenantModelBulkIn

# TODO update the JSON string below
json = "{}"
# create an instance of TenantModelBulkIn from a JSON string
tenant_model_bulk_in_instance = TenantModelBulkIn.from_json(json)
# print the JSON string representation of the object
print(TenantModelBulkIn.to_json())

# convert the object into a dict
tenant_model_bulk_in_dict = tenant_model_bulk_in_instance.to_dict()
# create an instance of TenantModelBulkIn from a dict
tenant_model_bulk_in_from_dict = TenantModelBulkIn.from_dict(tenant_model_bulk_in_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


