# VariableSpec

A single variable an email template may reference.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Placeholder name, used as {{ name }} in the body. | 
**required** | **bool** | Whether the template must reference this variable. | [optional] [default to False]
**description** | **str** | What the variable renders to. | 
**example** | [**Example**](Example.md) |  | [optional] 

## Example

```python
from neuland_hub_sdk.models.variable_spec import VariableSpec

# TODO update the JSON string below
json = "{}"
# create an instance of VariableSpec from a JSON string
variable_spec_instance = VariableSpec.from_json(json)
# print the JSON string representation of the object
print(VariableSpec.to_json())

# convert the object into a dict
variable_spec_dict = variable_spec_instance.to_dict()
# create an instance of VariableSpec from a dict
variable_spec_from_dict = VariableSpec.from_dict(variable_spec_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


