# ApplicationGroupOut

A group's application access, identifying app and group by public id.  `app_id`/`group_id` (int) are kept alongside the public ids (dual-key — both are returned permanently); external clients should reference `app_public_id`/`group_public_id`.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**app_id** | **int** | Internal id of the application (deprecated; use app_public_id). | 
**app_public_id** | **UUID** | Public id of the application. | 
**group_id** | **int** | Internal id of the user group (deprecated; use group_public_id). | 
**group_public_id** | **UUID** | Public id of the user group. | 
**tenant_id** | **int** | Internal id of the tenant the access belongs to. | 
**created_at** | **datetime** | Timestamp when the access was created. | 

## Example

```python
from neuland_hub_sdk.models.application_group_out import ApplicationGroupOut

# TODO update the JSON string below
json = "{}"
# create an instance of ApplicationGroupOut from a JSON string
application_group_out_instance = ApplicationGroupOut.from_json(json)
# print the JSON string representation of the object
print(ApplicationGroupOut.to_json())

# convert the object into a dict
application_group_out_dict = application_group_out_instance.to_dict()
# create an instance of ApplicationGroupOut from a dict
application_group_out_from_dict = ApplicationGroupOut.from_dict(application_group_out_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


