# MessageFileOut


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | ID of the attached document. | 
**public_id** | **UUID** | Public, non-enumerable id of the attached document. | 
**filename** | **str** | Original file name. | 
**content_type** | **str** |  | 

## Example

```python
from neuland_hub_sdk.models.message_file_out import MessageFileOut

# TODO update the JSON string below
json = "{}"
# create an instance of MessageFileOut from a JSON string
message_file_out_instance = MessageFileOut.from_json(json)
# print the JSON string representation of the object
print(MessageFileOut.to_json())

# convert the object into a dict
message_file_out_dict = message_file_out_instance.to_dict()
# create an instance of MessageFileOut from a dict
message_file_out_from_dict = MessageFileOut.from_dict(message_file_out_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


