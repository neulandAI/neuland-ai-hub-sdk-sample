# SettingsIn


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**default_llm_catalog_id** | **UUID** |  | [optional] 
**guardrails_enabled** | **bool** |  | [optional] 
**sharepoint_enabled** | **bool** |  | [optional] 
**inbound_guardrail** | **str** |  | [optional] 
**outbound_guardrail** | **str** |  | [optional] 
**welcome_email_template_id** | **UUID** |  | [optional] 
**project_member_added_email_template_id** | **UUID** |  | [optional] 
**system_prompt** | **str** |  | [optional] 
**errlog_webhook_url** | **str** |  | [optional] 
**require_email_confirmation** | **bool** |  | [optional] 
**budget_alert_enabled** | **bool** |  | [optional] 
**soft_limit_warning_enabled** | **bool** |  | [optional] 

## Example

```python
from neuland_hub_sdk.models.settings_in import SettingsIn

# TODO update the JSON string below
json = "{}"
# create an instance of SettingsIn from a JSON string
settings_in_instance = SettingsIn.from_json(json)
# print the JSON string representation of the object
print(SettingsIn.to_json())

# convert the object into a dict
settings_in_dict = settings_in_instance.to_dict()
# create an instance of SettingsIn from a dict
settings_in_from_dict = SettingsIn.from_dict(settings_in_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


