# EmailTemplateKey

Email template identifiers with namespaced keys.

## Enum

* `AUTH_DOT_PASS_DOT_RESET` (value: `'auth.pass.reset'`)

* `AUTH_DOT_PASS_DOT_RESET_DOT_OAUTH` (value: `'auth.pass.reset.oauth'`)

* `AUTH_DOT_PASS_DOT_RESET_DOT_CONFIRM` (value: `'auth.pass.reset.confirm'`)

* `AUTH_DOT_EMAIL_DOT_CONFIRM` (value: `'auth.email.confirm'`)

* `AUTH_DOT_INVITATION` (value: `'auth.invitation'`)

* `USERS_DOT_WELCOME` (value: `'users.welcome'`)

* `PROJECTS_DOT_MEMBERS_DOT_ADD` (value: `'projects.members.add'`)

* `PROJECTS_DOT_MEMBERS_DOT_REMOVE` (value: `'projects.members.remove'`)

* `ASSISTANTS_DOT_MEMBERS_DOT_ADD` (value: `'assistants.members.add'`)

* `ASSISTANTS_DOT_MEMBERS_DOT_REMOVE` (value: `'assistants.members.remove'`)

* `APPS_DOT_MEMBERS_DOT_ADD` (value: `'apps.members.add'`)

* `APPS_DOT_MEMBERS_DOT_REMOVE` (value: `'apps.members.remove'`)

* `BUDGET_DOT_ALERT` (value: `'budget.alert'`)

* `SOFT_DOT_LIMIT_DOT_REACHED` (value: `'soft.limit.reached'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


