# Cc

CC recipients

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from neuland_hub_sdk.models.cc import Cc

# TODO update the JSON string below
json = "{}"
# create an instance of Cc from a JSON string
cc_instance = Cc.from_json(json)
# print the JSON string representation of the object
print(Cc.to_json())

# convert the object into a dict
cc_dict = cc_instance.to_dict()
# create an instance of Cc from a dict
cc_from_dict = Cc.from_dict(cc_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


