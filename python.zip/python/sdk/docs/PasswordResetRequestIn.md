# PasswordResetRequestIn


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **str** | Email address of the account to send a reset link to. | 

## Example

```python
from neuland_hub_sdk.models.password_reset_request_in import PasswordResetRequestIn

# TODO update the JSON string below
json = "{}"
# create an instance of PasswordResetRequestIn from a JSON string
password_reset_request_in_instance = PasswordResetRequestIn.from_json(json)
# print the JSON string representation of the object
print(PasswordResetRequestIn.to_json())

# convert the object into a dict
password_reset_request_in_dict = password_reset_request_in_instance.to_dict()
# create an instance of PasswordResetRequestIn from a dict
password_reset_request_in_from_dict = PasswordResetRequestIn.from_dict(password_reset_request_in_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


