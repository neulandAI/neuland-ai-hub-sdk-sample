# UserIn


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first_name** | **str** | User&#39;s given name. | 
**last_name** | **str** | User&#39;s family name. | 
**email** | **str** | Email address used to log in; must be unique. | 
**password** | **str** | Initial password; the user is prompted to change it on first login. | 
**admin** | **bool** |  | [optional] 
**superadmin** | **bool** |  | [optional] 
**tenant_id** | **UUID** |  | [optional] 
**role_id** | **UUID** |  | [optional] 

## Example

```python
from neuland_hub_sdk.models.user_in import UserIn

# TODO update the JSON string below
json = "{}"
# create an instance of UserIn from a JSON string
user_in_instance = UserIn.from_json(json)
# print the JSON string representation of the object
print(UserIn.to_json())

# convert the object into a dict
user_in_dict = user_in_instance.to_dict()
# create an instance of UserIn from a dict
user_in_from_dict = UserIn.from_dict(user_in_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


