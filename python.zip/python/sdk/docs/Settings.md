# neuland_hub_sdk.Settings

All URIs are relative to *https://api.your-domain.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**settings_current**](Settings.md#settings_current) | **GET** /settings/current | Get current tenant settings
[**settings_update_current_settings**](Settings.md#settings_update_current_settings) | **PATCH** /settings/current | Update current tenant settings
[**settings_update_settings**](Settings.md#settings_update_settings) | **PATCH** /settings/{settings_id} | Update settings by id


# **settings_current**
> Settings settings_current(cookie_name=cookie_name)

Get current tenant settings

Get the settings for the current user's tenant, creating defaults if absent.

### Example

* Api Key Authentication (APIKeyHeader):

```python
import neuland_hub_sdk
from neuland_hub_sdk.models.settings import Settings
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: APIKeyHeader
configuration.api_key['APIKeyHeader'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['APIKeyHeader'] = 'Bearer'

# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Settings(api_client)
    cookie_name = 'cookie_name_example' # str |  (optional)

    try:
        # Get current tenant settings
        api_response = api_instance.settings_current(cookie_name=cookie_name)
        print("The response of Settings->settings_current:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling Settings->settings_current: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cookie_name** | **str**|  | [optional] 

### Return type

[**Settings**](Settings.md)

### Authorization

[APIKeyHeader](../README.md#APIKeyHeader)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **settings_update_current_settings**
> Settings settings_update_current_settings(settings_in, cookie_name=cookie_name)

Update current tenant settings

Update the settings for the current user's tenant (tenant admin only).

### Example

* Api Key Authentication (APIKeyHeader):

```python
import neuland_hub_sdk
from neuland_hub_sdk.models.settings import Settings
from neuland_hub_sdk.models.settings_in import SettingsIn
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: APIKeyHeader
configuration.api_key['APIKeyHeader'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['APIKeyHeader'] = 'Bearer'

# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Settings(api_client)
    settings_in = neuland_hub_sdk.SettingsIn() # SettingsIn | 
    cookie_name = 'cookie_name_example' # str |  (optional)

    try:
        # Update current tenant settings
        api_response = api_instance.settings_update_current_settings(settings_in, cookie_name=cookie_name)
        print("The response of Settings->settings_update_current_settings:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling Settings->settings_update_current_settings: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **settings_in** | [**SettingsIn**](SettingsIn.md)|  | 
 **cookie_name** | **str**|  | [optional] 

### Return type

[**Settings**](Settings.md)

### Authorization

[APIKeyHeader](../README.md#APIKeyHeader)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |
**403** | Tenant admin privileges required. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **settings_update_settings**
> Settings settings_update_settings(settings_id, settings_in, cookie_name=cookie_name)

Update settings by id

Update a tenant's settings by id (tenant admin; some fields superadmin-only).

### Example

* Api Key Authentication (APIKeyHeader):

```python
import neuland_hub_sdk
from neuland_hub_sdk.models.settings import Settings
from neuland_hub_sdk.models.settings_in import SettingsIn
from neuland_hub_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.your-domain.com
# See configuration.py for a list of all supported configuration parameters.
configuration = neuland_hub_sdk.Configuration(
    host = "https://api.your-domain.com"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: APIKeyHeader
configuration.api_key['APIKeyHeader'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['APIKeyHeader'] = 'Bearer'

# Enter a context with an instance of the API client
with neuland_hub_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = neuland_hub_sdk.Settings(api_client)
    settings_id = UUID('38400000-8cf0-11bd-b23e-10b96e4ef00d') # UUID | Public id of the settings record to update.
    settings_in = neuland_hub_sdk.SettingsIn() # SettingsIn | 
    cookie_name = 'cookie_name_example' # str |  (optional)

    try:
        # Update settings by id
        api_response = api_instance.settings_update_settings(settings_id, settings_in, cookie_name=cookie_name)
        print("The response of Settings->settings_update_settings:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling Settings->settings_update_settings: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **settings_id** | **UUID**| Public id of the settings record to update. | 
 **settings_in** | [**SettingsIn**](SettingsIn.md)|  | 
 **cookie_name** | **str**|  | [optional] 

### Return type

[**Settings**](Settings.md)

### Authorization

[APIKeyHeader](../README.md#APIKeyHeader)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**401** | Missing or invalid authentication. |  -  |
**403** | Tenant admin privileges required, or superadmin required to change protected fields. |  -  |
**404** | No settings record exists with the given id. |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

