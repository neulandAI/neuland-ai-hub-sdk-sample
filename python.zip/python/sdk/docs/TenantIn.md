# TenantIn


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Internal name of the tenant. | 
**slug** | **str** | URL-safe unique identifier for the tenant. | 
**domain** | **str** |  | [optional] 
**parent_tenant_id** | **UUID** |  | [optional] 
**subtenants_enabled** | **bool** |  | [optional] 
**timezone** | **str** |  | [optional] 
**locale** | **str** |  | [optional] 
**tarif_id** | **UUID** |  | [optional] 
**tarif_expires_at** | **datetime** |  | [optional] 
**max_users** | **int** |  | [optional] 
**max_projects** | **int** |  | [optional] 
**licenses** | **int** |  | [optional] 
**display_name** | **str** |  | [optional] 
**motto** | **str** |  | [optional] 
**logo_url** | **str** |  | [optional] 
**square_logo_url** | **str** |  | [optional] 
**favicon_url** | **str** |  | [optional] 
**chat_square_logo_url** | **str** |  | [optional] 
**primary_color** | **str** |  | [optional] 
**secondary_color** | **str** |  | [optional] 
**theme** | **str** |  | [optional] 
**storage_limit_gb** | **int** |  | [optional] 
**api_rate_limit** | **int** |  | [optional] 
**upstream_tenant_id** | **str** |  | [optional] 
**upstream_oidc_issuer** | **str** |  | [optional] 

## Example

```python
from neuland_hub_sdk.models.tenant_in import TenantIn

# TODO update the JSON string below
json = "{}"
# create an instance of TenantIn from a JSON string
tenant_in_instance = TenantIn.from_json(json)
# print the JSON string representation of the object
print(TenantIn.to_json())

# convert the object into a dict
tenant_in_dict = tenant_in_instance.to_dict()
# create an instance of TenantIn from a dict
tenant_in_from_dict = TenantIn.from_dict(tenant_in_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


