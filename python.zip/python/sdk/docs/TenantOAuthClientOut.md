# TenantOAuthClientOut


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tenant_id** | **int** | ID of the tenant this OAuth client configuration belongs to. | 
**oauth_client_id** | **int** | ID of the platform OAuth client this configuration overrides. | 
**provider_key** | [**OAuth2ProviderEnum**](OAuth2ProviderEnum.md) | OAuth provider key backing this client. | 
**client_id** | **str** | OAuth client identifier issued by the provider. | 
**authorize_url** | **str** | Provider authorization endpoint URL. | 
**token_url** | **str** | Provider token endpoint URL. | 
**revocation_url** | **str** |  | [optional] 
**redirect_uri** | **str** |  | [optional] 
**admin_consent_url** | **str** |  | [optional] 

## Example

```python
from neuland_hub_sdk.models.tenant_o_auth_client_out import TenantOAuthClientOut

# TODO update the JSON string below
json = "{}"
# create an instance of TenantOAuthClientOut from a JSON string
tenant_o_auth_client_out_instance = TenantOAuthClientOut.from_json(json)
# print the JSON string representation of the object
print(TenantOAuthClientOut.to_json())

# convert the object into a dict
tenant_o_auth_client_out_dict = tenant_o_auth_client_out_instance.to_dict()
# create an instance of TenantOAuthClientOut from a dict
tenant_o_auth_client_out_from_dict = TenantOAuthClientOut.from_dict(tenant_o_auth_client_out_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


