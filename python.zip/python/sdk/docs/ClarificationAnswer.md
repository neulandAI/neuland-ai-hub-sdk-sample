# ClarificationAnswer

User's answer to one pending `ask_user_question` call.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**selected_option_ids** | **List[str]** |  | [optional] 
**text** | **str** |  | [optional] 
**confirmed** | **bool** |  | [optional] 

## Example

```python
from neuland_hub_sdk.models.clarification_answer import ClarificationAnswer

# TODO update the JSON string below
json = "{}"
# create an instance of ClarificationAnswer from a JSON string
clarification_answer_instance = ClarificationAnswer.from_json(json)
# print the JSON string representation of the object
print(ClarificationAnswer.to_json())

# convert the object into a dict
clarification_answer_dict = clarification_answer_instance.to_dict()
# create an instance of ClarificationAnswer from a dict
clarification_answer_from_dict = ClarificationAnswer.from_dict(clarification_answer_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


